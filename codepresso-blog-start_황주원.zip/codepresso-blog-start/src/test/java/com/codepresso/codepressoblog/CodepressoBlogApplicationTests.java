package com.codepresso.codepressoblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodepressoBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
